﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string f = "f";
            string m = "m";
            string e;
            

            do
            {
                Console.Clear();
                Console.WriteLine("Digite o seu sexo, sendo entre F ou M");
                e = Console.ReadLine();
               
            } while (e != f && e != m);
            Console.WriteLine("Condição correta!");
            











        }
    }
}
