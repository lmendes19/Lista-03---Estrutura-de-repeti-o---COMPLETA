﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PExercicio07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            for ( int e = 1; e <= 20; e++)
            {
                Console.Write("Aperte qualquer tecla e obtenha os valores da tabuada de um a vinte no intervalo de um a dez");
                Console.ReadLine();
                for (int c = 1; c <= 10; c++)

                {
                    Console.WriteLine(e + " x " + c + " = " + e * c);
                }
            }

        }
    }
}
